
const STORAGE_KEY = 'epy_inventory_v1';
let inventory = [];
let currentIndex = 0;

async function loadBaseInventory(){
  const res = await fetch('../data.json');
  return await res.json();
}

function byId(id){ return document.getElementById(id); }

function currentItem(){
  return inventory[currentIndex] || null;
}

function renderList(){
  const wrap = byId('admin-list');
  wrap.innerHTML = inventory.map((item, i)=>`
    <div class="admin-item ${i===currentIndex?'active':''}" data-index="${i}">
      <strong>${item.name || 'Untitled listing'}</strong><br>
      <span class="muted">${item.location || ''}</span>
    </div>
  `).join('');
  wrap.querySelectorAll('.admin-item').forEach(el=>{
    el.addEventListener('click', ()=>{
      currentIndex = Number(el.dataset.index);
      fillForm();
      renderList();
    });
  });
}

function fillForm(){
  const item = currentItem();
  if(!item) return;
  byId('slug').value = item.slug || '';
  byId('name').value = item.name || '';
  byId('type').value = item.type || '';
  byId('length').value = item.length || '';
  byId('length_ft').value = item.length_ft || '';
  byId('price').value = item.price || '';
  byId('price_num').value = item.price_num || '';
  byId('location').value = item.location || '';
  byId('summary').value = item.summary || '';
  byId('overview').value = item.overview || '';
  byId('image').value = item.image || '';
  byId('specs').value = JSON.stringify(item.specs || {}, null, 2);
  byId('gallery').value = JSON.stringify(item.gallery || [], null, 2);
  renderPreview();
}

function saveFormIntoCurrent(){
  const item = currentItem();
  if(!item) return;
  item.slug = byId('slug').value.trim() || `listing-${Date.now()}`;
  item.name = byId('name').value.trim();
  item.type = byId('type').value.trim();
  item.length = byId('length').value.trim();
  item.length_ft = Number(byId('length_ft').value || 0);
  item.price = byId('price').value.trim();
  item.price_num = Number(byId('price_num').value || 0);
  item.location = byId('location').value.trim();
  item.summary = byId('summary').value.trim();
  item.overview = byId('overview').value.trim();
  item.image = byId('image').value.trim();
  try{
    item.specs = JSON.parse(byId('specs').value || '{}');
  }catch(e){
    alert('Specs must be valid JSON.');
    throw e;
  }
  try{
    item.gallery = JSON.parse(byId('gallery').value || '[]');
  }catch(e){
    alert('Gallery must be valid JSON array.');
    throw e;
  }
}

function renderPreview(){
  const item = currentItem();
  if(!item) return;
  byId('preview-name').textContent = item.name || 'Untitled listing';
  byId('preview-meta').textContent = `${item.location || ''} ${item.length ? '· ' + item.length : ''}`;
  byId('preview-price').textContent = item.price || '';
  byId('preview-image').src = item.image || '';
  const gallery = item.gallery || [];
  byId('gallery-preview').innerHTML = gallery.map(src=>`<img src="${src}" alt="">`).join('');
}

function saveBrowserInventory(){
  try{
    saveFormIntoCurrent();
  }catch(e){
    return;
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(inventory));
  renderList();
  renderPreview();
  byId('status').textContent = 'Saved in this browser. The site will now use this inventory on this device.';
}

function resetInventory(){
  localStorage.removeItem(STORAGE_KEY);
  location.reload();
}

function exportInventory(){
  try{
    saveFormIntoCurrent();
  }catch(e){
    return;
  }
  const blob = new Blob([JSON.stringify(inventory, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'inventory.json';
  a.click();
  URL.revokeObjectURL(a.href);
}

function addListing(){
  inventory.unshift({
    slug: `listing-${Date.now()}`,
    name: 'New Yacht Listing',
    type: 'Cabin Cruiser',
    length_ft: 0,
    length: '',
    price_num: 0,
    price: '',
    location: '',
    image: '',
    summary: '',
    overview: '',
    specs: {},
    gallery: []
  });
  currentIndex = 0;
  renderList();
  fillForm();
}

function removeListing(){
  if(!inventory.length) return;
  if(!confirm('Remove this listing?')) return;
  inventory.splice(currentIndex, 1);
  if(currentIndex >= inventory.length) currentIndex = Math.max(0, inventory.length - 1);
  if(!inventory.length) addListing();
  renderList();
  fillForm();
}

function importJsonFile(file){
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const parsed = JSON.parse(reader.result);
      if(!Array.isArray(parsed)) throw new Error('Inventory file must be an array.');
      inventory = parsed;
      currentIndex = 0;
      renderList();
      fillForm();
      byId('status').textContent = 'Inventory imported into the admin editor.';
    }catch(e){
      alert('That JSON file could not be imported.');
    }
  };
  reader.readAsText(file);
}

function attachPhotoFiles(files){
  const item = currentItem();
  if(!item) return;
  const gallery = Array.isArray(item.gallery) ? item.gallery : [];
  let pending = files.length;
  [...files].forEach(file=>{
    const reader = new FileReader();
    reader.onload = () => {
      gallery.push(reader.result);
      if(!item.image) item.image = reader.result;
      pending--;
      if(pending === 0){
        item.gallery = gallery;
        byId('image').value = item.image || '';
        byId('gallery').value = JSON.stringify(item.gallery, null, 2);
        renderPreview();
        byId('status').textContent = 'Photos added to the current listing. Click Save in Browser to use them.';
      }
    };
    reader.readAsDataURL(file);
  });
}

async function initAdmin(){
  const local = localStorage.getItem(STORAGE_KEY);
  if(local){
    try{ inventory = JSON.parse(local); }catch(e){}
  }
  if(!Array.isArray(inventory) || !inventory.length){
    inventory = await loadBaseInventory();
  }

  renderList();
  fillForm();

  byId('save-browser').addEventListener('click', saveBrowserInventory);
  byId('export-json').addEventListener('click', exportInventory);
  byId('reset-browser').addEventListener('click', resetInventory);
  byId('add-listing').addEventListener('click', addListing);
  byId('remove-listing').addEventListener('click', removeListing);

  byId('form').addEventListener('input', ()=>{
    try{ saveFormIntoCurrent(); renderList(); renderPreview(); }catch(e){}
  });

  byId('import-json').addEventListener('change', (e)=>{
    if(e.target.files[0]) importJsonFile(e.target.files[0]);
  });

  byId('upload-photos').addEventListener('change', (e)=>{
    if(e.target.files.length) attachPhotoFiles(e.target.files);
  });
}

document.addEventListener('DOMContentLoaded', initAdmin);
