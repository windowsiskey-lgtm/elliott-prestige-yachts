
async function loadInventory(){
  const res = await fetch('../data.json').catch(()=>fetch('data.json'));
  return await res.json();
}
function resolveImage(path, prefix=''){
  if(/^https?:/i.test(path)) return path;
  if(path.startsWith('/')) return `${prefix}${path.slice(1)}`;
  return `${prefix}${path}`;
}
function cardHTML(item, prefix=''){
  return `
  <article class="card">
    <a class="media" href="${prefix}inventory/${item.slug}.html"><img src="${resolveImage(item.image, prefix)}" alt="${item.name}"></a>
    <div class="card-body">
      <div class="eyebrow">${item.type}</div>
      <h3>${item.name}</h3>
      <div class="meta"><span>${item.length}</span><span>${item.location}</span></div>
      <p class="muted">${item.summary}</p>
      <div style="display:flex;justify-content:space-between;align-items:center;gap:14px;margin-top:16px">
        <div class="price">${item.price}</div>
        <a class="btn-secondary" href="${prefix}inventory/${item.slug}.html">View Yacht</a>
      </div>
    </div>
  </article>`;
}
async function renderHome(){
  const wrap = document.getElementById('featured-grid');
  if(!wrap) return;
  const data = await loadInventory();
  wrap.innerHTML = data.slice(0,3).map(x=>cardHTML(x,'')).join('');
}
async function renderInventory(){
  const wrap = document.getElementById('inventory-grid');
  if(!wrap) return;
  const q = document.getElementById('q');
  const type = document.getElementById('type');
  const loc = document.getElementById('loc');
  const sort = document.getElementById('sort');
  const data = await loadInventory();

  function overlayCard(item){
    return `
      <article class="inventory-overlay-card">
        <img src="${resolveImage(item.image, '../')}" alt="${item.name}">
        <a class="overlay-link" href="../inventory/${item.slug}.html" aria-label="${item.name}"></a>
        <div class="content">
          <div class="eyebrow">${item.name}</div>
          <div class="price">${item.price}</div>
          <div class="meta">${item.location}</div>
        </div>
      </article>
    `;
  }

  function apply(){
    let rows = [...data].filter(item=>{
      const hay = `${item.name} ${item.type} ${item.location} ${item.length}`.toLowerCase();
      return (!q.value || hay.includes(q.value.toLowerCase()))
        && (!type.value || item.type.toLowerCase().includes(type.value.toLowerCase()))
        && (!loc.value || item.location.toLowerCase().includes(loc.value.toLowerCase()));
    });

    if(sort.value === 'price-asc'){
      rows.sort((a,b)=>a.price_num-b.price_num);
    } else if(sort.value === 'price-desc'){
      rows.sort((a,b)=>b.price_num-a.price_num);
    } else if(sort.value === 'length-desc'){
      rows.sort((a,b)=>b.length_ft-a.length_ft);
    }

    wrap.innerHTML = rows.length ? rows.map(overlayCard).join('') : `<div class="empty">No yachts matched that search. Try broadening your filters.</div>`;
  }

  [q,type,loc,sort].forEach(el=>el && el.addEventListener('input', apply));
  [q,type,loc,sort].forEach(el=>el && el.addEventListener('change', apply));
  apply();
}
function initHeroSearch(){
  const form = document.getElementById('hero-search');
  if(!form) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const q = document.getElementById('hero-q').value.trim();
    const type = document.getElementById('hero-type').value.trim();
    const loc = document.getElementById('hero-loc').value.trim();
    const url = new URL('inventory/index.html', window.location.href);
    if(q) url.searchParams.set('q', q);
    if(type) url.searchParams.set('type', type);
    if(loc) url.searchParams.set('loc', loc);
    window.location.href = url.toString();
  });
}
function initInventoryQuery(){
  const page = document.getElementById('inventory-grid');
  if(!page) return;
  const params = new URLSearchParams(window.location.search);
  const q = document.getElementById('q');
  const type = document.getElementById('type');
  const loc = document.getElementById('loc');
  if(q && params.get('q')) q.value = params.get('q');
  if(type && params.get('type')) type.value = params.get('type');
  if(loc && params.get('loc')) loc.value = params.get('loc');
}
document.addEventListener('DOMContentLoaded', ()=>{
  renderHome();
  initHeroSearch();
  initInventoryQuery();
  renderInventory();
});


async function renderOverlayListings(){
  const wrap = document.getElementById('featured-overlay-grid');
  if(!wrap) return;
  const data = await loadInventory();
  const rows = [...data].slice(0,3);
  wrap.innerHTML = rows.map(item => `
    <article class="overlay-card">
      <img src="${resolveImage(item.image, '')}" alt="${item.name}">
      <a class="overlay-link" href="inventory/${item.slug}.html" aria-label="${item.name}"></a>
      <div class="overlay-content">
        <div class="eyebrow">${item.name}</div>
        <div class="overlay-price">${item.price}</div>
        <div class="overlay-meta">${item.location}</div>
      </div>
    </article>
  `).join('');
}

function initHomeQuickLinks(){
  document.querySelectorAll('[data-home-link]').forEach(el=>{
    el.addEventListener('click', (e)=>{
      e.preventDefault();
      const url = new URL('inventory/index.html', window.location.href);
      const q = el.getAttribute('data-q');
      const type = el.getAttribute('data-type');
      const loc = el.getAttribute('data-loc');
      if(q) url.searchParams.set('q', q);
      if(type) url.searchParams.set('type', type);
      if(loc) url.searchParams.set('loc', loc);
      window.location.href = url.toString();
    });
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  renderOverlayListings();
  initHomeQuickLinks();
});
