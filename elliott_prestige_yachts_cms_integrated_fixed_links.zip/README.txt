ELLIOTT PRESTIGE YACHTS WEBSITE

Upload everything inside this zip to Netlify.

Notes:
- The homepage uses a streaming MP4 video source in the hero section.
- The chosen logo from the provided image is included as:
  /assets/images/logo.png
- Inventory is powered by data.json
- Main pages:
  index.html
  inventory/index.html
  power-cruisers.html
  motor-yachts.html
  sell-your-yacht.html
  about.html
  contact.html

If you want to replace the homepage hero video later, edit index.html and swap the <source src=""> URL.


Added listing: 1999 Sea Ray Sundancer 290 (Rocinante)

Homepage rebuilt to mobile-first, no-border, image-overlay listing style.

Inventory page updated to overlay listing style and reduced to Sea Ray Sundancer 290 only.


Admin page added:
- /admin/index.html
- Save inventory changes in browser for live preview on the same device/browser
- Export inventory.json for permanent deployment updates
- Upload photos directly into listing data for preview/export
- Inventory detail pages now use /inventory/view.html?slug=...


CMS INTEGRATION NOTES

This version keeps the full site/navigation intact and adds Decap CMS at /admin.

Before the admin will publish changes, Netlify must be set up to use:
1. A Git-connected deploy (GitHub/GitLab/Bitbucket), not manual drag-and-drop zip deploy
2. Netlify Identity enabled
3. Git Gateway enabled
4. At least one invited admin user

Important:
- If you upload this as a ZIP manually, the public site works, but /admin will not be able to publish.
- To make changes publish, connect the site to a repo and redeploy from Git.
- Inventory content now lives in /content/yachts/*.md
