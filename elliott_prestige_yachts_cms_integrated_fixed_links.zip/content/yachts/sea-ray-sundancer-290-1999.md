---
title: "1999 Sea Ray Sundancer 290"
slug: "sea-ray-sundancer-290-1999"
type: "Cabin Cruiser"
length: "29'8\""
length_ft: 30
price: "$34,900"
price_num: 34900
location: "Portland, Oregon"
image: "assets/images/inventory/searay-290-1999/photo-1.jpg"
summary: "Clean Pacific Northwest express cruiser with twin MerCruiser 4.3L power, roomy cockpit seating, and a comfortable cabin below."
overview: "The Sea Ray Sundancer 290 is a proven cabin cruiser with the right balance of cockpit space, overnight comfort, and manageable size. Rocinante presents well with a bright white exterior, teak-style cockpit flooring, a comfortable helm layout, and a welcoming cabin with dinette, galley, and forward berth. This is the kind of cruiser that makes sense for weekend trips, entertaining at the dock, and easy coastal or river cruising around the Pacific Northwest."
gallery:
  - "assets/images/inventory/searay-290-1999/photo-1.jpg"
  - "assets/images/inventory/searay-290-1999/photo-2.jpg"
  - "assets/images/inventory/searay-290-1999/photo-3.jpg"
  - "assets/images/inventory/searay-290-1999/photo-4.jpg"
  - "assets/images/inventory/searay-290-1999/photo-5.jpg"
  - "assets/images/inventory/searay-290-1999/photo-6.jpg"
  - "assets/images/inventory/searay-290-1999/photo-7.jpg"
  - "assets/images/inventory/searay-290-1999/photo-8.jpg"
  - "assets/images/inventory/searay-290-1999/photo-9.jpg"
  - "assets/images/inventory/searay-290-1999/photo-10.jpg"
specs:
  "Year": "1999"
  "Type": "Cabin Cruiser"
  "Length": "29'8\""
  "Location": "Portland, Oregon"
  "Engines": "Twin MerCruiser 4.3L"
  "Fuel": "Gasoline"
  "Berths": "Forward berth + salon conversion"
  "Notable": "Garmin electronics, cockpit seating, enclosed cabin"
---

The Sea Ray Sundancer 290 is a proven cabin cruiser with the right balance of cockpit space, overnight comfort, and manageable size. Rocinante presents well with a bright white exterior, teak-style cockpit flooring, a comfortable helm layout, and a welcoming cabin with dinette, galley, and forward berth. This is the kind of cruiser that makes sense for weekend trips, entertaining at the dock, and easy coastal or river cruising around the Pacific Northwest.
