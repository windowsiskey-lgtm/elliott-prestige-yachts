
function inventoryFileCandidates(){
  const depth = window.location.pathname.split('/').filter(Boolean).length;
  const candidates = [
    '/content/inventory.json',
    '../content/inventory.json',
    '../../content/inventory.json',
    'content/inventory.json'
  ];
  return [...new Set(candidates)];
}

async function fetchJsonCandidates(paths){
  for(const path of paths){
    try{
      const res = await fetch(path, {cache:'no-store'});
      if(res.ok) return await res.json();
    }catch(e){}
  }
  throw new Error('Could not load inventory JSON.');
}

async function loadInventory(){
  const data = await fetchJsonCandidates(inventoryFileCandidates());
  if(Array.isArray(data)) return data;
  if(Array.isArray(data.inventory)) return data.inventory;
  return [];
}

function resolveImage(path, prefix=''){
  if(!path) return '';
  if(/^data:/i.test(path)) return path;
  if(/^https?:/i.test(path)) return path;
  if(path.startsWith('/')) return `${prefix}${path.slice(1)}`;
  return `${prefix}${path}`;
}

function detailLink(item, prefix=''){
  return `${prefix}inventory/view.html?slug=${encodeURIComponent(item.slug)}`;
}

async function renderOverlayListings(){
  const wrap = document.getElementById('featured-overlay-grid');
  if(!wrap) return;
  const data = await loadInventory();
  const rows = [...data].slice(0,3);
  wrap.innerHTML = rows.map(item => `
    <article class="overlay-card">
      <img src="${resolveImage(item.image, '')}" alt="${item.name}">
      <a class="overlay-link" href="${detailLink(item, '')}" aria-label="${item.name}"></a>
      <div class="overlay-content">
        <div class="eyebrow">${item.name}</div>
        <div class="overlay-price">${item.price}</div>
        <div class="overlay-meta">${item.location}</div>
      </div>
    </article>
  `).join('');
}

function initHomeQuickLinks(){
  document.querySelectorAll('[data-home-link]').forEach(el=>{
    el.addEventListener('click', (e)=>{
      e.preventDefault();
      const url = new URL('inventory/index.html', window.location.href);
      const q = el.getAttribute('data-q');
      const type = el.getAttribute('data-type');
      const loc = el.getAttribute('data-loc');
      if(q) url.searchParams.set('q', q);
      if(type) url.searchParams.set('type', type);
      if(loc) url.searchParams.set('loc', loc);
      window.location.href = url.toString();
    });
  });
}

async function renderInventory(){
  const wrap = document.getElementById('inventory-grid');
  if(!wrap) return;
  const q = document.getElementById('q');
  const type = document.getElementById('type');
  const loc = document.getElementById('loc');
  const sort = document.getElementById('sort');
  const data = await loadInventory();

  function overlayCard(item){
    return `
      <article class="inventory-overlay-card">
        <img src="${resolveImage(item.image, '../')}" alt="${item.name}">
        <a class="overlay-link" href="${detailLink(item, '../')}" aria-label="${item.name}"></a>
        <div class="content">
          <div class="eyebrow">${item.name}</div>
          <div class="price">${item.price}</div>
          <div class="meta">${item.location}</div>
        </div>
      </article>
    `;
  }

  function apply(){
    let rows = [...data].filter(item=>{
      const hay = `${item.name} ${item.type} ${item.location} ${item.length} ${(item.summary||'')}`.toLowerCase();
      return (!q.value || hay.includes(q.value.toLowerCase()))
        && (!type.value || (item.type||'').toLowerCase().includes(type.value.toLowerCase()))
        && (!loc.value || (item.location||'').toLowerCase().includes(loc.value.toLowerCase()));
    });

    if(sort && sort.value === 'price-asc'){
      rows.sort((a,b)=>(a.price_num||0)-(b.price_num||0));
    } else if(sort && sort.value === 'price-desc'){
      rows.sort((a,b)=>(b.price_num||0)-(a.price_num||0));
    } else if(sort && sort.value === 'length-desc'){
      rows.sort((a,b)=>(b.length_ft||0)-(a.length_ft||0));
    } else {
      rows.sort((a,b)=>((b.featured===true)-(a.featured===true)) || ((b.price_num||0)-(a.price_num||0)));
    }

    wrap.innerHTML = rows.length ? rows.map(overlayCard).join('') : `<div class="info-card">No yachts matched that search. Try broadening your filters.</div>`;
  }

  [q,type,loc,sort].forEach(el=>el && el.addEventListener('input', apply));
  [q,type,loc,sort].forEach(el=>el && el.addEventListener('change', apply));
  apply();
}

async function renderFeaturedHero(){
  const hero = document.getElementById('featured-now-card');
  if(!hero) return;
  const data = await loadInventory();
  const item = data.find(x=>x.featured) || data[0];
  if(!item) return;
  hero.querySelector('.featured-name').textContent = item.name;
  hero.querySelector('.featured-price').textContent = item.price;
  hero.querySelector('.featured-meta').textContent = item.location;
  hero.querySelector('img').src = resolveImage(item.image,'');
  hero.querySelector('a').href = detailLink(item,'');
}

async function renderDetailPage(){
  const page = document.querySelector('[data-detail-page]');
  if(!page) return;
  const params = new URLSearchParams(window.location.search);
  const slug = params.get('slug');
  const data = await loadInventory();
  const item = data.find(x => x.slug === slug) || data[0];
  if(!item) return;

  document.title = `${item.name} | Elliott Prestige Yachts`;
  const set = (id, value) => {
    const el = document.getElementById(id);
    if(el) el.textContent = value || '';
  };

  set('detail-kicker', item.type || 'Yacht Listing');
  set('detail-name', item.name || '');
  set('detail-sub', `${item.location || ''} · ${item.length || ''}`);
  set('detail-price', item.price || '');
  set('detail-summary', item.summary || '');
  set('detail-overview', item.overview || '');

  const hero = document.getElementById('detail-hero-img');
  if(hero) hero.src = resolveImage(item.image, '../');

  const gallery = document.getElementById('detail-gallery');
  if(gallery){
    const imgs = Array.isArray(item.gallery) && item.gallery.length ? item.gallery : [item.image];
    gallery.innerHTML = imgs.map((src, i)=>`
      <div class="panel"><img src="${resolveImage(src, '../')}" alt="${item.name} image ${i+1}"></div>
    `).join('');
  }

  const specs = document.getElementById('detail-specs');
  if(specs){
    const specRows = item.specs || {};
    specs.innerHTML = Object.entries(specRows).map(([k,v])=>`<tr><td>${k}</td><td>${v}</td></tr>`).join('');
  }

  const cta = document.getElementById('detail-inquiry-link');
  if(cta) cta.href = `../contact.html?boat=${encodeURIComponent(item.name)}`;
}

document.addEventListener('DOMContentLoaded', ()=>{
  renderOverlayListings();
  initHomeQuickLinks();
  renderInventory();
  renderFeaturedHero();
  renderDetailPage();
});
