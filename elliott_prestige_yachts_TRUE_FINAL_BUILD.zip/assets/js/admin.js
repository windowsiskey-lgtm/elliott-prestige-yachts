
const INVENTORY_PATH = '../content/inventory.json';
let inventoryData = { inventory: [] };
let currentIndex = 0;

function byId(id){ return document.getElementById(id); }
function currentItem(){ return inventoryData.inventory[currentIndex] || null; }

async function loadInventoryJson(){
  const res = await fetch(INVENTORY_PATH, {cache:'no-store'});
  inventoryData = await res.json();
  if(!Array.isArray(inventoryData.inventory)) inventoryData.inventory = [];
}

function renderList(){
  const wrap = byId('admin-list');
  wrap.innerHTML = inventoryData.inventory.map((item, i)=>`
    <div class="admin-item ${i===currentIndex?'active':''}" data-index="${i}">
      <strong>${item.name || 'Untitled listing'}</strong><br>
      <span class="muted">${item.location || ''}</span>
    </div>
  `).join('');
  wrap.querySelectorAll('.admin-item').forEach(el=>{
    el.addEventListener('click', ()=>{
      currentIndex = Number(el.dataset.index);
      fillForm();
      renderList();
    });
  });
}

function fillForm(){
  const item = currentItem();
  if(!item) return;
  byId('slug').value = item.slug || '';
  byId('name').value = item.name || '';
  byId('type').value = item.type || '';
  byId('length').value = item.length || '';
  byId('length_ft').value = item.length_ft || '';
  byId('price').value = item.price || '';
  byId('price_num').value = item.price_num || '';
  byId('location').value = item.location || '';
  byId('featured').checked = !!item.featured;
  byId('summary').value = item.summary || '';
  byId('overview').value = item.overview || '';
  byId('image').value = item.image || '';
  byId('specs').value = JSON.stringify(item.specs || {}, null, 2);
  byId('gallery').value = JSON.stringify(item.gallery || [], null, 2);
  renderPreview();
}

function saveFormIntoCurrent(){
  const item = currentItem();
  if(!item) return;
  item.slug = byId('slug').value.trim() || `listing-${Date.now()}`;
  item.name = byId('name').value.trim();
  item.type = byId('type').value.trim();
  item.length = byId('length').value.trim();
  item.length_ft = Number(byId('length_ft').value || 0);
  item.price = byId('price').value.trim();
  item.price_num = Number(byId('price_num').value || 0);
  item.location = byId('location').value.trim();
  item.featured = !!byId('featured').checked;
  item.summary = byId('summary').value.trim();
  item.overview = byId('overview').value.trim();
  item.image = byId('image').value.trim();
  item.specs = JSON.parse(byId('specs').value || '{}');
  item.gallery = JSON.parse(byId('gallery').value || '[]');
}

function renderPreview(){
  const item = currentItem();
  if(!item) return;
  byId('preview-name').textContent = item.name || 'Untitled listing';
  byId('preview-meta').textContent = `${item.location || ''} ${item.length ? '· ' + item.length : ''}`;
  byId('preview-price').textContent = item.price || '';
  byId('preview-image').src = item.image || '';
  const gallery = item.gallery || [];
  byId('gallery-preview').innerHTML = gallery.map(src=>`<img src="${src}" alt="">`).join('');
}

function exportInventory(){
  try{
    saveFormIntoCurrent();
  }catch(e){
    alert('Please fix the JSON in specs or gallery before exporting.');
    return;
  }
  const blob = new Blob([JSON.stringify(inventoryData, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'inventory.json';
  a.click();
  URL.revokeObjectURL(a.href);
  byId('status').textContent = 'Exported inventory.json. Replace /content/inventory.json in the repo if needed.';
}

function addListing(){
  inventoryData.inventory.unshift({
    slug: `listing-${Date.now()}`,
    name: 'New Yacht Listing',
    type: 'Power Cruiser',
    length: '',
    length_ft: 0,
    price: '',
    price_num: 0,
    location: '',
    featured: false,
    image: '',
    summary: '',
    overview: '',
    gallery: [],
    specs: {}
  });
  currentIndex = 0;
  renderList();
  fillForm();
}

function removeListing(){
  if(!inventoryData.inventory.length) return;
  if(!confirm('Remove this listing?')) return;
  inventoryData.inventory.splice(currentIndex, 1);
  if(currentIndex >= inventoryData.inventory.length) currentIndex = Math.max(0, inventoryData.inventory.length - 1);
  if(!inventoryData.inventory.length) addListing();
  renderList();
  fillForm();
}

function attachPhotoFiles(files){
  const item = currentItem();
  if(!item) return;
  const gallery = Array.isArray(item.gallery) ? item.gallery : [];
  let pending = files.length;
  [...files].forEach(file=>{
    const reader = new FileReader();
    reader.onload = () => {
      gallery.push(reader.result);
      if(!item.image) item.image = reader.result;
      pending--;
      if(pending === 0){
        item.gallery = gallery;
        byId('image').value = item.image || '';
        byId('gallery').value = JSON.stringify(item.gallery, null, 2);
        renderPreview();
        byId('status').textContent = 'Photos added to the current listing. Save or export next.';
      }
    };
    reader.readAsDataURL(file);
  });
}

async function initAdmin(){
  await loadInventoryJson();
  if(!inventoryData.inventory.length) addListing();
  renderList();
  fillForm();

  byId('form').addEventListener('input', ()=>{
    try{
      saveFormIntoCurrent();
      renderList();
      renderPreview();
    }catch(e){}
  });

  byId('add-listing').addEventListener('click', addListing);
  byId('remove-listing').addEventListener('click', removeListing);
  byId('export-json').addEventListener('click', exportInventory);
  byId('upload-photos').addEventListener('change', (e)=>{
    if(e.target.files.length) attachPhotoFiles(e.target.files);
  });
}

document.addEventListener('DOMContentLoaded', initAdmin);
